start :-
    write("Enter the date of the month (1-31): "), read(Day),
    write("Enter the month number (1-12): "), read(Month),
    zodiac(Day, Month, Sign),
    write("Your zodiac sign is: "), write(Sign), nl.

zodiac(Day, 3, 'Pisces') :-
    Day >= 1, Day =< 20.

zodiac(Day, 3, 'Aries') :-
    Day >= 21, Day =< 31.

zodiac(Day, 4, 'Aries') :-
    Day >= 1, Day =< 19.

zodiac(Day, 4, 'Taurus') :-
    Day >= 20, Day =< 30.

zodiac(Day, 5, 'Taurus') :-
    Day >= 1, Day =< 20.

zodiac(Day, 5, 'Gemini') :-
    Day >= 21, Day =< 31.

zodiac(Day, 6, 'Gemini') :-
    Day >= 1, Day =< 20.

zodiac(Day, 6, 'Cancer') :-
    Day >= 21, Day =< 30.

zodiac(Day, 7, 'Cancer') :-
    Day >= 1, Day =< 22.

zodiac(Day, 7, 'Leo') :-
    Day >= 23, Day =< 31.

zodiac(Day, 8, 'Leo') :-
    Day >= 1, Day =< 22
    .
zodiac(Day, 8, 'Virgo') :-
    Day >= 23, Day =< 31.

zodiac(Day, 9, 'Virgo') :-
    Day >= 1, Day =< 22.

zodiac(Day, 9, 'Libra') :-
    Day >= 23, Day =< 30.

zodiac(Day, 10, 'Libra') :-
    Day >= 1, Day =< 22.

zodiac(Day, 10, 'Scorpio') :-
    Day >= 23, Day =< 31.

zodiac(Day, 11, 'Scorpio') :-
    Day >= 1, Day =< 21.

zodiac(Day, 11, 'Sagittarius') :-
    Day >= 22, Day =< 30.

zodiac(Day, 12, 'Sagittarius') :- Day >= 1, Day =< 21.

zodiac(Day, 12, 'Capricorn') :- Day >= 22, Day =< 31.