def hill_climbing(graph, start_node):
    current_node = start_node
    while True:
    
        children = graph[current_node]['children']

        if not children:
            return current_node 
        
        best_child = max(children, key=lambda child: graph[child]['value'])
        
        
        if graph[best_child]['value'] <= graph[current_node]['value']:
            return current_node

        
        current_node = best_child

graph = {
    'A' : {'value' : 10,'children': ['B', 'C', 'D']},
    'B' : {'value' : 20,'children': []},
    'C' : {'value' : 30,'children': ['E', 'F']},
    'D' : {'value' : 15,'children': []},
    'E' : {'value' : 35,'children': []},
    'F' : {'value' : 25,'children': []}
}

result = hill_climbing(graph, 'A')
print(f"Reached node with value: {graph[result]['value']} (Node:{result})")
