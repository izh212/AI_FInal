import random

POPULATION_SIZE = 10
GENES = 5  
MUTATION_RATE = 0.1
CROSSOVER_RATE = 0.7
GENERATIONS = 50

import random
import math

class GA:
    def __init__(self, individualSize, populationSize):
        self.population = dict()
        self.individualSize = individualSize
        self.populationSize = populationSize
        self.totalFitness = 0
        i = 0
        while i < populationSize:
            listOfBits = [0] * individualSize
            listOfLocations = list(range(0, individualSize))
            numberOfOnes = random.randint(0, individualSize - 1)
            onesLocations = random.sample(listOfLocations, numberOfOnes)
            for j in onesLocations:
                listOfBits[j] = 1
            self.population[i] = [listOfBits, numberOfOnes]
            self.totalFitness += numberOfOnes
            i += 1

    def updatePopulationFitness(self):
        self.totalFitness = 0
        for individual in self.population:
            individualFitness = sum(self.population[individual][0])
            self.population[individual][1] = individualFitness
            self.totalFitness += individualFitness

    def selectParents(self):
        wheelSize = self.populationSize * 5
        h_n = []
        for individual in self.population:
            h_n.append(self.population[individual][1])
        j = 0
        rouletteWheel = []
        for individual in self.population:
            individuallength = round(wheelSize * (h_n[j] / sum(h_n)))
            if individuallength > 0:
                i = 0
                while i < individuallength:
                    rouletteWheel.append(individual)
                    i += 1
            j += 1
        random.shuffle(rouletteWheel)
        parentIndices = []
        i = 0
        while i < self.populationSize:
            parentIndices.append(rouletteWheel[random.randint(0, len(rouletteWheel) - 1)])
            i += 1
        newGeneration = dict()
        i = 0
        while i < self.populationSize:
            newGeneration[i] = self.population[parentIndices[i]].copy()
            i += 1
        del self.population
        self.population = newGeneration.copy()
        self.updatePopulationFitness()

    def generateChildren(self, crossoverProbability):
        numberOfPairs = round(crossoverProbability * self.populationSize / 2)
        individualIndices = list(range(0, self.populationSize))
        random.shuffle(individualIndices)
        i = 0
        j = 0
        while i < numberOfPairs:
            crossoverPoint = random.randint(0, self.individualSize - 1)
            child1 = self.population[j][0][:crossoverPoint] + self.population[j + 1][0][crossoverPoint:]
            child2 = self.population[j + 1][0][:crossoverPoint] + self.population[j][0][crossoverPoint:]
            self.population[j] = [child1, sum(child1)]
            self.population[j + 1] = [child2, sum(child2)]
            i += 1
            j += 2
        self.updatePopulationFitness()

    def mutateChildren(self, mutationProbability):
        numberOfBits = round(mutationProbability * self.populationSize * self.individualSize)
        totalIndices = list(range(0, self.populationSize * self.individualSize))
        random.shuffle(totalIndices)
        swapLocations = random.sample(totalIndices, numberOfBits)
        for loc in swapLocations:
            individualIndex = math.floor(loc / self.individualSize)
            bitIndex = loc % self.individualSize
            if self.population[individualIndex][0][bitIndex] == 0:
                self.population[individualIndex][0][bitIndex] = 1
            else:
                self.population[individualIndex][0][bitIndex] = 0
        self.updatePopulationFitness()

individualSize, populationSize = 8, 10
i = 0
instance = GA(individualSize, populationSize)
while True:
    instance.selectParents()
    instance.generateChildren(0.8)
    instance.mutateChildren(0.03)
    print(instance.population)
    print(instance.totalFitness)
    print(i)
    i += 1
    found = False
    for individual in instance.population:
        if instance.population[individual][1] == individualSize:
            found = True
            break
    if found:
        break

def fitness_function(x):
    return x**2  

def create_chromosome():
    return [random.randint(0, 1) for _ in range(GENES)]

def decode_chromosome(chromosome):
    return int("".join(map(str, chromosome)), 2)

def initialize_population():
    return [create_chromosome() for _ in range(POPULATION_SIZE)]

def evaluate_population(population):
    return [fitness_function(decode_chromosome(chromosome)) for chromosome in population]

def select_parent(population, fitness_values):
    total_fitness = sum(fitness_values)
    probabilities = [f / total_fitness for f in fitness_values]
    cumulative_probs = [sum(probabilities[:i+1]) for i in range(len(probabilities))]
    r = random.random()
    for i, cp in enumerate(cumulative_probs):
        if r <= cp:
            return population[i]

def crossover(parent1, parent2):
    if random.random() > CROSSOVER_RATE:
        return parent1[:], parent2[:]
    point = random.randint(1, GENES - 1)
    return parent1[:point] + parent2[point:], parent2[:point] + parent1[point:]

def mutate(chromosome):
    for i in range(len(chromosome)):
        if random.random() < MUTATION_RATE:
            chromosome[i] = 1 - chromosome[i]  


def genetic_algorithm():
    population = initialize_population()

    for generation in range(GENERATIONS):
        fitness_values = evaluate_population(population)
        best_fitness = max(fitness_values)
        best_chromosome = population[fitness_values.index(best_fitness)]
        print(f"Generation {generation + 1}: Best Fitness = {best_fitness}")
        new_population = []
        for _ in range(POPULATION_SIZE // 2):
            parent1 = select_parent(population, fitness_values)
            parent2 = select_parent(population, fitness_values)
            offspring1, offspring2 = crossover(parent1, parent2)
            mutate(offspring1)
            mutate(offspring2)
            new_population.extend([offspring1, offspring2])
        population = new_population

    best_fitness = max(fitness_values)
    best_chromosome = population[fitness_values.index(best_fitness)]
    best_value = decode_chromosome(best_chromosome)
    print(f"Best solution found: x = {best_value}, f(x) = {best_fitness}")

if __name__ == "__main__":
    genetic_algorithm()