start :-
    write("Enter your choice of days and cost:"), nl,
    write("What is your days limit: "), read(Day),
    write("What is your cost limit: "), read(Cost),
    checkpackage(Day, Cost).

checkpackage(Day, Cost) :-
    Day > 0, Day < 6, Cost = 800, brahamaputra, !;
    Day > 5, Day < 8, Cost = 1000, ganges, !;
    Day > 7, Day < 15, Cost = 1500, indus, !;
    write("No suitable package found."), nl.

brahamaputra :-
    write("Package suitable to you is Brahamaputra."), nl.

ganges :-
    write("Package suitable to you is Ganges."), nl.

indus :-
    write("Package suitable to you is Indus."), nl.